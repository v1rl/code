#include <bits/stdc++.h>
using namespace std;
using i64 = long long;

template <typename Info>
struct SegmentTree
{
    int n;
    vector<Info> info;

    SegmentTree(int n_) : n(n_), info(4 * n + 1) {};
    SegmentTree(vector<Info> a) : SegmentTree(a.size() - 1)
    {
        function<void(int, int, int)> build = [&](int p, int l, int r)
        {
            if(l == r)
            {
                info[p] = a[l];
                return;
            }
            int mid = l + r >> 1;
            build(p << 1, l, mid);
            build(p << 1 | 1, mid + 1, r);
            pushup(p);
        };
        build(1, 1, n);
    }

    void pushup(int p)
    {
        info[p] = info[p << 1] + info[p << 1 | 1];
    }

    void modify(int p, int l, int r, int x, const int &v)
    {
        if(l == r)
        {
            info[p].apply(v);
            return;
        }
        int mid = l + r >> 1;
        if(x <= mid) modify(p << 1, l, mid, x, v);
        else modify(p << 1 | 1, mid + 1, r, x, v);
        pushup(p);
    }

    void modify(int x, const int &v)
    {
        modify(1, 1, n, x, v);
    }

    Info query(int p, int l, int r, int x, int y)
    {
        if(y < l || x > r) return Info();
        if(x <= l && r <= y) return info[p];
        int mid = l + r >> 1;
        return query(p << 1, l, mid, x, y) + query(p << 1 | 1, mid + 1, r, x, y);
    }

    Info query(int x, int y)
    {
        return query(1, 1, n, x, y);
    }
};

struct Info
{
    int sum = 0;
    void apply(const int &v)
    {
        sum += v;
    }
};
Info operator+(Info a, Info b)
{
    Info c;
    c.sum = a.sum + b.sum;
    return c;
}

int main()
{
    ios::sync_with_stdio(false), cin.tie(0), cout.tie(0);
    int n;
    cin >> n;
    vector<Info> a(n + 1);
    for(int i = 1; i <= n; i ++) cin >> a[i].sum;
    SegmentTree<Info> tr(a);
    tr.modify(3, 3);
    cout << tr.query(1, 5).sum << '\n';
}